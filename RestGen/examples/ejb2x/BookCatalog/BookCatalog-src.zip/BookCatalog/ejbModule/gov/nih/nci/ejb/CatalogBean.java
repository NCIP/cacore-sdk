package gov.nih.nci.ejb;

import javax.ejb.*;
import java.util.*;

public class CatalogBean implements SessionBean {
  List shelf;

  public CatalogBean() {
    shelf = new ArrayList();
    Book book1 = new Book();
    book1.setId("1");
    book1.setTitle("Book1");
    book1.setAuthor("Author1");
    book1.setIbn("IBN1");
    shelf.add(book1);
    Book book2 = new Book();
    book2.setId("2");
    book2.setTitle("Book2");
    book2.setAuthor("Author2");
    book2.setIbn("IBN2");
    shelf.add(book2);
  }

  public void addBook(Book book) {
    shelf.add(book);
  }

  public Book getBook(String name)
  {
	return (Book)shelf.get(0);  
  }
  
  public List<Book> getBooks() {
    return shelf;
  }

  public void deleteBook(String id) {
	  Iterator iter = shelf.iterator();
	  while(iter.hasNext())
	  {
		  Book book = (Book) iter.next();
		  if(book.getId().endsWith(id))
			  shelf.remove(book);
	  }
  }

  public void updateBook(Book ubook) {
	  Iterator iter = shelf.iterator();
	  while(iter.hasNext())
	  {
		  Book book = (Book) iter.next();
		  if(book.getId().endsWith(ubook.getId()))
		  {
			  book.setTitle(ubook.getTitle());
			  book.setAuthor(ubook.getAuthor());
			  book.setIbn(ubook.getIbn());
		  }
	  }
  }
  
  
  public void ejbCreate() {
    System.out.println("calling ejbcreate....");
  }

  public void ejbRemove() {
    System.out.println("calling ejbremove");
  }

  public void ejbActivate() {
    System.out.println("calling ejbactivate");
  }

  public void ejbPassivate() {
    System.out.println("calling ejbpassivate");
  }

  public void setSessionContext(SessionContext sc) {
    System.out.println("calling session context");
  }

}