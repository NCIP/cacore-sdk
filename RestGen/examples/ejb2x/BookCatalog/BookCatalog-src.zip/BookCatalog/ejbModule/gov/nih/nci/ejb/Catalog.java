package gov.nih.nci.ejb;

import javax.ejb.*;
import java.rmi.*;
import java.util.*;

public interface Catalog extends EJBObject {
  public void addBook(Book book) throws RemoteException;

  public Book getBook(String name) throws RemoteException;
  
  public List<Book> getBooks() throws RemoteException;

  public void deleteBook(String id) throws RemoteException;
  
  public void updateBook(Book book) throws RemoteException;
  
}