package gov.nih.nci.codegen.transformer.jet;

import gov.nih.nci.codegen.transformer.UMLClassJetTransformer;
import gov.nih.nci.codegen.Artifact;
import gov.nih.nci.codegen.artifact.BaseArtifact;
import gov.nih.nci.codegen.util.TransformerUtils;
import gov.nih.nci.codegen.GenerationException;

import gov.nih.nci.ncicb.xmiinout.domain.UMLModel;
import gov.nih.nci.ncicb.xmiinout.domain.UMLClass;
import gov.nih.nci.ncicb.xmiinout.domain.UMLAttribute;
import gov.nih.nci.ncicb.xmiinout.domain.UMLAssociation;
import gov.nih.nci.ncicb.xmiinout.domain.UMLAssociationEnd;
import gov.nih.nci.ncicb.xmiinout.domain.UMLGeneralization;

import java.util.Collection;
import java.util.List;


public class HibernateMappingTransformer extends UMLClassJetTransformer{
	
	  protected final String NL = System.getProperties().getProperty("line.separator");
  protected final String TEXT_1 = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + NL + "<!DOCTYPE hibernate-mapping PUBLIC \"-//Hibernate/Hibernate Mapping DTD 3.0//EN\" \"http://hibernate.sourceforge.net/hibernate-mapping-3.0.dtd\">" + NL + "<hibernate-mapping package=\"";
  protected final String TEXT_2 = "\" auto-import=\"false\" default-cascade=\"none\">" + NL + "\t<class name=\"";
  protected final String TEXT_3 = "\" table=\"";
  protected final String TEXT_4 = "\" lazy=\"true\" polymorphism=\"";
  protected final String TEXT_5 = "\" abstract=\"";
  protected final String TEXT_6 = "\" ";
  protected final String TEXT_7 = ">" + NL + "\t\t<cache usage=\"read-write\" />" + NL + "\t\t<id name=\"";
  protected final String TEXT_8 = "\" type=\"";
  protected final String TEXT_9 = "\" column=\"";
  protected final String TEXT_10 = "\">";
  protected final String TEXT_11 = NL + "\t\t\t";
  protected final String TEXT_12 = NL + "\t\t\t<generator class=\"";
  protected final String TEXT_13 = "\">";
  protected final String TEXT_14 = "\t" + NL + "\t\t\t\t<param name=\"";
  protected final String TEXT_15 = "\">";
  protected final String TEXT_16 = "</param>";
  protected final String TEXT_17 = NL + "\t\t\t</generator>";
  protected final String TEXT_18 = "\t\t\t" + NL + "\t\t</id>";
  protected final String TEXT_19 = NL + "\t\t";
  protected final String TEXT_20 = "<discriminator column=\"";
  protected final String TEXT_21 = "\" type=\"string\"/>";
  protected final String TEXT_22 = NL + "\t\t";
  protected final String TEXT_23 = "<!-- Attributes mapping for the ";
  protected final String TEXT_24 = " class -->";
  protected final String TEXT_25 = NL + "\t\t";
  protected final String TEXT_26 = "<set name=\"";
  protected final String TEXT_27 = "\" lazy=\"false\" table=\"";
  protected final String TEXT_28 = "\">" + NL + "\t\t\t";
  protected final String TEXT_29 = "<cache usage=\"read-write\" />" + NL + "\t\t\t";
  protected final String TEXT_30 = "<key column=\"";
  protected final String TEXT_31 = "\" />" + NL + "\t\t\t";
  protected final String TEXT_32 = "<element type=\"";
  protected final String TEXT_33 = "\" column=\"";
  protected final String TEXT_34 = "\" />" + NL + "\t\t";
  protected final String TEXT_35 = "</set>" + NL + "\t\t\t\t\t\t";
  protected final String TEXT_36 = NL + "\t\t";
  protected final String TEXT_37 = "<property name=\"";
  protected final String TEXT_38 = "\" type=\"";
  protected final String TEXT_39 = "\" column=\"";
  protected final String TEXT_40 = "\"/>";
  protected final String TEXT_41 = NL + "\t\t";
  protected final String TEXT_42 = "<!-- Associations mapping for the ";
  protected final String TEXT_43 = " class -->";
  protected final String TEXT_44 = NL + "\t\t";
  protected final String TEXT_45 = "<any name=\"";
  protected final String TEXT_46 = "\" meta-type=\"string\" id-type=\"integer\" lazy=\"";
  protected final String TEXT_47 = "\" cascade=\"";
  protected final String TEXT_48 = "\">";
  protected final String TEXT_49 = NL + "\t\t\t";
  protected final String TEXT_50 = "<meta-value value=\"";
  protected final String TEXT_51 = "\" class=\"";
  protected final String TEXT_52 = "\"/>";
  protected final String TEXT_53 = NL + "\t\t\t";
  protected final String TEXT_54 = "<column name=\"";
  protected final String TEXT_55 = "\"/>" + NL + "\t\t\t";
  protected final String TEXT_56 = "<column name=\"";
  protected final String TEXT_57 = "\"/>" + NL + "\t\t";
  protected final String TEXT_58 = "</any>";
  protected final String TEXT_59 = NL + "\t\t";
  protected final String TEXT_60 = "<set name=\"";
  protected final String TEXT_61 = "\" table=\"";
  protected final String TEXT_62 = "\" lazy=\"";
  protected final String TEXT_63 = "\" inverse=\"";
  protected final String TEXT_64 = "\">" + NL + "\t\t\t";
  protected final String TEXT_65 = "<cache usage=\"read-write\" />" + NL + "\t\t\t";
  protected final String TEXT_66 = "<key column=\"";
  protected final String TEXT_67 = "\" />" + NL + "\t\t\t";
  protected final String TEXT_68 = "<many-to-any meta-type=\"string\" id-type=\"integer\">";
  protected final String TEXT_69 = NL + "\t\t\t";
  protected final String TEXT_70 = "<meta-value value=\"";
  protected final String TEXT_71 = "\" class=\"";
  protected final String TEXT_72 = "\"/>";
  protected final String TEXT_73 = NL + "\t\t\t";
  protected final String TEXT_74 = "<column name=\"";
  protected final String TEXT_75 = "\"/>" + NL + "\t\t\t";
  protected final String TEXT_76 = "<column name=\"";
  protected final String TEXT_77 = "\"/>" + NL + "\t\t\t";
  protected final String TEXT_78 = "</many-to-any>" + NL + "\t\t";
  protected final String TEXT_79 = "</set>";
  protected final String TEXT_80 = NL + "\t\t";
  protected final String TEXT_81 = "<set name=\"";
  protected final String TEXT_82 = "\" table=\"";
  protected final String TEXT_83 = "\" lazy=\"";
  protected final String TEXT_84 = "\" inverse=\"";
  protected final String TEXT_85 = "\">" + NL + "\t\t\t";
  protected final String TEXT_86 = "<cache usage=\"read-write\" />" + NL + "\t\t\t";
  protected final String TEXT_87 = "<key column=\"";
  protected final String TEXT_88 = "\" />" + NL + "\t\t\t";
  protected final String TEXT_89 = "<many-to-many class=\"";
  protected final String TEXT_90 = "\" column=\"";
  protected final String TEXT_91 = "\" />" + NL + "\t\t";
  protected final String TEXT_92 = "</set>";
  protected final String TEXT_93 = NL + "\t\t";
  protected final String TEXT_94 = "<set name=\"";
  protected final String TEXT_95 = "\" lazy=\"";
  protected final String TEXT_96 = "\" cascade=\"";
  protected final String TEXT_97 = "\" inverse=\"";
  protected final String TEXT_98 = "\">" + NL + "\t\t\t";
  protected final String TEXT_99 = "<cache usage=\"read-write\" />" + NL + "\t\t\t";
  protected final String TEXT_100 = "<key column=\"";
  protected final String TEXT_101 = "\" not-null=\"";
  protected final String TEXT_102 = "\" />" + NL + "\t\t\t";
  protected final String TEXT_103 = "<one-to-many class=\"";
  protected final String TEXT_104 = "\"/>" + NL + "\t\t";
  protected final String TEXT_105 = "</set>";
  protected final String TEXT_106 = NL + "\t\t";
  protected final String TEXT_107 = "<set name=\"";
  protected final String TEXT_108 = "\" table=\"";
  protected final String TEXT_109 = "\" lazy=\"";
  protected final String TEXT_110 = "\" cascade=\"";
  protected final String TEXT_111 = "\" inverse=\"";
  protected final String TEXT_112 = "\">" + NL + "\t\t\t";
  protected final String TEXT_113 = "<cache usage=\"read-write\" />" + NL + "\t\t\t";
  protected final String TEXT_114 = "<key column=\"";
  protected final String TEXT_115 = "\" />" + NL + "\t\t\t";
  protected final String TEXT_116 = "<many-to-many class=\"";
  protected final String TEXT_117 = "\" column=\"";
  protected final String TEXT_118 = "\" unique=\"true\"/>" + NL + "\t\t";
  protected final String TEXT_119 = "</set>";
  protected final String TEXT_120 = NL + "\t\t\t";
  protected final String TEXT_121 = "<many-to-one name=\"";
  protected final String TEXT_122 = "\" class=\"";
  protected final String TEXT_123 = "\" column=\"";
  protected final String TEXT_124 = "\" lazy=\"";
  protected final String TEXT_125 = "\" not-null=\"";
  protected final String TEXT_126 = "\" cascade=\"";
  protected final String TEXT_127 = "\"/>";
  protected final String TEXT_128 = NL + "\t\t";
  protected final String TEXT_129 = "<many-to-one name=\"";
  protected final String TEXT_130 = "\" class=\"";
  protected final String TEXT_131 = "\" column=\"";
  protected final String TEXT_132 = "\" unique=\"true\" lazy=\"";
  protected final String TEXT_133 = "\" not-null=\"";
  protected final String TEXT_134 = "\" cascade=\"";
  protected final String TEXT_135 = "\"/>";
  protected final String TEXT_136 = NL + "\t\t";
  protected final String TEXT_137 = "<one-to-one name=\"";
  protected final String TEXT_138 = "\" class=\"";
  protected final String TEXT_139 = "\" property-ref=\"";
  protected final String TEXT_140 = "\" lazy=\"";
  protected final String TEXT_141 = "\" cascade=\"";
  protected final String TEXT_142 = "\"/>";
  protected final String TEXT_143 = NL + "\t\t";
  protected final String TEXT_144 = "<many-to-one name=\"";
  protected final String TEXT_145 = "\" class=\"";
  protected final String TEXT_146 = "\" column=\"";
  protected final String TEXT_147 = "\" unique=\"true\" lazy=\"";
  protected final String TEXT_148 = "\" not-null=\"";
  protected final String TEXT_149 = "\" cascade=\"";
  protected final String TEXT_150 = "\"/>";
  protected final String TEXT_151 = NL + "\t\t";
  protected final String TEXT_152 = "<join table=\"";
  protected final String TEXT_153 = "\" inverse=\"";
  protected final String TEXT_154 = "\" optional=\"true\">" + NL + "\t\t\t";
  protected final String TEXT_155 = "<key column=\"";
  protected final String TEXT_156 = "\" />" + NL + "\t\t\t";
  protected final String TEXT_157 = "<many-to-one name=\"";
  protected final String TEXT_158 = "\" column=\"";
  protected final String TEXT_159 = "\" class=\"";
  protected final String TEXT_160 = "\" lazy=\"";
  protected final String TEXT_161 = "\" not-null=\"";
  protected final String TEXT_162 = "\" cascade=\"";
  protected final String TEXT_163 = "\"/>" + NL + "\t\t";
  protected final String TEXT_164 = "</join>";
  protected final String TEXT_165 = NL + "\t\t";
  protected final String TEXT_166 = "<join table=\"";
  protected final String TEXT_167 = "\" inverse=\"";
  protected final String TEXT_168 = "\" optional=\"true\">" + NL + "\t\t\t";
  protected final String TEXT_169 = "<key column=\"";
  protected final String TEXT_170 = "\" />" + NL + "\t\t\t";
  protected final String TEXT_171 = "<many-to-one name=\"";
  protected final String TEXT_172 = "\" column=\"";
  protected final String TEXT_173 = "\" class=\"";
  protected final String TEXT_174 = "\" unique=\"true\" lazy=\"";
  protected final String TEXT_175 = "\" not-null=\"";
  protected final String TEXT_176 = "\" cascade=\"";
  protected final String TEXT_177 = "\"/>" + NL + "\t\t";
  protected final String TEXT_178 = "</join>";
  protected final String TEXT_179 = NL + "\t\t";
  protected final String TEXT_180 = "<joined-subclass name=\"";
  protected final String TEXT_181 = "\" table=\"";
  protected final String TEXT_182 = "\" lazy=\"true\">" + NL + "\t\t\t";
  protected final String TEXT_183 = "<key column=\"";
  protected final String TEXT_184 = "\" />";
  protected final String TEXT_185 = NL + "\t\t";
  protected final String TEXT_186 = "</joined-subclass>";
  protected final String TEXT_187 = NL + "\t\t";
  protected final String TEXT_188 = "<subclass name=\"";
  protected final String TEXT_189 = "\" discriminator-value=\"";
  protected final String TEXT_190 = "\">";
  protected final String TEXT_191 = NL + "\t\t";
  protected final String TEXT_192 = "</subclass>";
  protected final String TEXT_193 = NL + "\t\t";
  protected final String TEXT_194 = "<subclass name=\"";
  protected final String TEXT_195 = "\" discriminator-value=\"";
  protected final String TEXT_196 = "\">" + NL + "\t\t\t";
  protected final String TEXT_197 = "<join table=\"";
  protected final String TEXT_198 = "\">" + NL + "\t\t\t\t";
  protected final String TEXT_199 = "<key column=\"";
  protected final String TEXT_200 = "\" />";
  protected final String TEXT_201 = NL + "\t\t\t";
  protected final String TEXT_202 = "</join>" + NL + "\t\t";
  protected final String TEXT_203 = "</subclass>";
  protected final String TEXT_204 = NL + "\t</class>" + NL + "</hibernate-mapping>";

public Artifact executeTemplate(UMLModel model, UMLClass klass) throws GenerationException{
		BaseArtifact artifact = new BaseArtifact(transformerUtils);
		String generatedContent = generate(model, klass, 0);
		artifact.setContent(generatedContent);
		artifact.createSourceName(klass);
		return artifact;
	}

	protected Collection<UMLClass> getAllClasses(UMLModel model) throws GenerationException{
		return transformerUtils.getAllHibernateClasses(model);	
	}	

	private String generate(UMLModel model, UMLClass klass, Integer level)  throws GenerationException
  {
    StringBuffer stringBuffer = new StringBuffer();
    UMLAttribute idAttr = transformerUtils.getClassIdAttr(klass);
String abstractModifier = transformerUtils.isAbstract(klass) ? "true" : "false";
String polymorphismAttr = transformerUtils.hasImplicitParent(klass) ? "implicit" : "explicit";
String fqcn = transformerUtils.getFQCN(klass);
UMLClass table = transformerUtils.getTable(klass);
String emptySpace = transformerUtils.getEmptySpace(level);
String discriminatorColumnName = transformerUtils.findDiscriminatingColumnName(klass);
if(level == 0){
String discriminatorValue = transformerUtils.getRootDiscriminatorValue(klass);
String discriminatorValueStr = (discriminatorValue==null) ? "" : "discriminator-value=\""+discriminatorValue+"\"";

    stringBuffer.append(TEXT_1);
    stringBuffer.append(transformerUtils.getFullPackageName(klass));
    stringBuffer.append(TEXT_2);
    stringBuffer.append(klass.getName());
    stringBuffer.append(TEXT_3);
    stringBuffer.append(table.getName());
    stringBuffer.append(TEXT_4);
    stringBuffer.append(polymorphismAttr);
    stringBuffer.append(TEXT_5);
    stringBuffer.append(abstractModifier);
    stringBuffer.append(TEXT_6);
    stringBuffer.append(discriminatorValueStr);
    stringBuffer.append(TEXT_7);
    stringBuffer.append(idAttr.getName());
    stringBuffer.append(TEXT_8);
    stringBuffer.append(transformerUtils.getHibernateDataType(klass,idAttr));
    stringBuffer.append(TEXT_9);
    stringBuffer.append(transformerUtils.getMappedColumnName(table,fqcn+"."+idAttr.getName()));
    stringBuffer.append(TEXT_10);
    
		java.util.HashMap<String,String> pkGeneratorTags=transformerUtils.getPKGeneratorTags(table,fqcn,idAttr);
		  String pkSystemwideGeneratorTag=pkGeneratorTags.get(transformerUtils.PK_GENERATOR_SYSTEMWIDE+transformerUtils.getDatabaseType());
		  if(pkSystemwideGeneratorTag!=null){
    stringBuffer.append(TEXT_11);
    stringBuffer.append(pkSystemwideGeneratorTag);
    
		  }else{
    stringBuffer.append(TEXT_12);
    stringBuffer.append(pkGeneratorTags.get(transformerUtils.TV_PK_GENERATOR+transformerUtils.getDatabaseType()));
    stringBuffer.append(TEXT_13);
    
					java.util.Iterator itr=pkGeneratorTags.keySet().iterator();
					 while(itr.hasNext()){
						String key=(String)itr.next();
						if(!key.equals(transformerUtils.TV_PK_GENERATOR+transformerUtils.getDatabaseType())){
		    			String value=(String)pkGeneratorTags.get(key);
    stringBuffer.append(TEXT_14);
    stringBuffer.append(key);
    stringBuffer.append(TEXT_15);
    stringBuffer.append(value);
    stringBuffer.append(TEXT_16);
    }
					}
    stringBuffer.append(TEXT_17);
    
			}
    stringBuffer.append(TEXT_18);
    
		if(discriminatorColumnName!=null && !discriminatorColumnName.equals("")){
    stringBuffer.append(TEXT_19);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_20);
    stringBuffer.append(discriminatorColumnName);
    stringBuffer.append(TEXT_21);
    
		}
}
		UMLClass currentKlass = klass;
		do{
			if(currentKlass.getAttributes().size()>0){
    stringBuffer.append(TEXT_22);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_23);
    stringBuffer.append(currentKlass.getName());
    stringBuffer.append(TEXT_24);
    
				for(UMLAttribute attr:currentKlass.getAttributes()){
					if(attr != idAttr){
						if(transformerUtils.isCollection(currentKlass, attr)){
							UMLClass collectionTable = transformerUtils.findCollectionTable(attr, model);
							String keyColumnName = transformerUtils.getCollectionKeyColumnName(collectionTable, currentKlass, attr);
							String elementColumnName = transformerUtils.getCollectionElementColumnName(collectionTable, currentKlass, attr);
							String elementType = transformerUtils.getCollectionElementHibernateType(currentKlass, attr);
    stringBuffer.append(TEXT_25);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_26);
    stringBuffer.append(attr.getName());
    stringBuffer.append(TEXT_27);
    stringBuffer.append(collectionTable.getName());
    stringBuffer.append(TEXT_28);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_29);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_30);
    stringBuffer.append(keyColumnName);
    stringBuffer.append(TEXT_31);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_32);
    stringBuffer.append(elementType);
    stringBuffer.append(TEXT_33);
    stringBuffer.append(elementColumnName);
    stringBuffer.append(TEXT_34);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_35);
    }
						else{
						    UMLClass temp;
							if (transformerUtils.isImplicitParent(currentKlass)){
								temp = klass;
							} else {
								temp = currentKlass;
							}
						
    stringBuffer.append(TEXT_36);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_37);
    stringBuffer.append(attr.getName());
    stringBuffer.append(TEXT_38);
    stringBuffer.append(transformerUtils.getHibernateDataType(temp,attr));
    stringBuffer.append(TEXT_39);
    stringBuffer.append(transformerUtils.getMappedColumnName(table,fqcn+"."+attr.getName()));
    stringBuffer.append(TEXT_40);
    
						}
					}
				}
			}
			if(currentKlass.getAssociations().size()>0){
    stringBuffer.append(TEXT_41);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_42);
    stringBuffer.append(currentKlass.getName());
    stringBuffer.append(TEXT_43);
    
				
				//First Pass - process 'set' elements >

				for(UMLAssociation association:currentKlass.getAssociations()){
					List<UMLAssociationEnd> assocEnds = association.getAssociationEnds();
					UMLAssociationEnd thisEnd = transformerUtils.getThisEnd(currentKlass,assocEnds);
					UMLAssociationEnd otherEnd = transformerUtils.getOtherEnd(currentKlass,assocEnds);
					
					if(otherEnd.isNavigable())
					{
						UMLClass assocKlass = (UMLClass)otherEnd.getUMLElement();
						String assocKlassName = transformerUtils.getFQCN(assocKlass);
						String cascadeStyle = transformerUtils.findCascadeStyle(currentKlass, otherEnd.getRoleName(), association);
						boolean lazy = transformerUtils.isLazyLoad(currentKlass, otherEnd.getRoleName(), association);
						
						if(transformerUtils.isAny(thisEnd,otherEnd)) //Association to an implicit parent class
						{
							String lazyValue = lazy == true ? "true" : "false";
							UMLClass implicitClass = (UMLClass)otherEnd.getUMLElement();
							UMLClass anyTable = transformerUtils.getTable(currentKlass);
							
    stringBuffer.append(TEXT_44);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_45);
    stringBuffer.append(otherEnd.getRoleName());
    stringBuffer.append(TEXT_46);
    stringBuffer.append(lazyValue);
    stringBuffer.append(TEXT_47);
    stringBuffer.append(cascadeStyle);
    stringBuffer.append(TEXT_48);
    
							for (UMLClass nonImplicitSubclass:transformerUtils.getNonImplicitSubclasses(implicitClass)){
    stringBuffer.append(TEXT_49);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_50);
    stringBuffer.append(transformerUtils.getDiscriminatorValue(nonImplicitSubclass));
    stringBuffer.append(TEXT_51);
    stringBuffer.append(transformerUtils.getFQCN(nonImplicitSubclass));
    stringBuffer.append(TEXT_52);
    
							}//for	
    stringBuffer.append(TEXT_53);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_54);
    stringBuffer.append(transformerUtils.getImplicitDiscriminatorColumn(anyTable,currentKlass,otherEnd.getRoleName()));
    stringBuffer.append(TEXT_55);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_56);
    stringBuffer.append(transformerUtils.getImplicitIdColumn(anyTable,currentKlass,otherEnd.getRoleName()));
    stringBuffer.append(TEXT_57);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_58);
    
						} else if(transformerUtils.isMany2Any(thisEnd,otherEnd)){
							String lazyValue = lazy == true ? "true" : "false";
							UMLClass correlationTable = transformerUtils.findCorrelationTable(association, model, assocKlass);
							String keyColumnName = transformerUtils.findAssociatedColumn(correlationTable,assocKlass,thisEnd, currentKlass,otherEnd, true);
							String assocColumnName = transformerUtils.findAssociatedColumn(correlationTable,currentKlass,otherEnd, assocKlass, thisEnd, true);
							String inverseColumnName =  transformerUtils.findInverseColumnValue(correlationTable,assocKlass,thisEnd);
							if(!"".equals(inverseColumnName) && !assocColumnName.equals(inverseColumnName))
								throw new GenerationException("Different columns used for 'implements-association' and 'inverse-of' tags of the same association");
							String inverseValue = assocColumnName.equals(inverseColumnName) ?"true":"false";
							String joinTableName = correlationTable.getName();
							UMLClass implicitClass = (UMLClass)otherEnd.getUMLElement();
							
							
    stringBuffer.append(TEXT_59);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_60);
    stringBuffer.append(otherEnd.getRoleName());
    stringBuffer.append(TEXT_61);
    stringBuffer.append(joinTableName);
    stringBuffer.append(TEXT_62);
    stringBuffer.append(lazyValue);
    stringBuffer.append(TEXT_63);
    stringBuffer.append(inverseValue);
    stringBuffer.append(TEXT_64);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_65);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_66);
    stringBuffer.append(keyColumnName);
    stringBuffer.append(TEXT_67);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_68);
    
							for (UMLClass nonImplicitSubclass:transformerUtils.getNonImplicitSubclasses(implicitClass)){
    stringBuffer.append(TEXT_69);
    stringBuffer.append(emptySpace);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_70);
    stringBuffer.append(transformerUtils.getDiscriminatorValue(nonImplicitSubclass));
    stringBuffer.append(TEXT_71);
    stringBuffer.append(transformerUtils.getFQCN(nonImplicitSubclass));
    stringBuffer.append(TEXT_72);
    
							}//for	
    stringBuffer.append(TEXT_73);
    stringBuffer.append(emptySpace);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_74);
    stringBuffer.append(transformerUtils.getImplicitDiscriminatorColumn(correlationTable,currentKlass,otherEnd.getRoleName()));
    stringBuffer.append(TEXT_75);
    stringBuffer.append(emptySpace);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_76);
    stringBuffer.append(transformerUtils.getImplicitIdColumn(correlationTable,currentKlass,otherEnd.getRoleName()));
    stringBuffer.append(TEXT_77);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_78);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_79);
    
						} else if(transformerUtils.isMany2Many(thisEnd,otherEnd)){
							String lazyValue = lazy == true ? "true" : "false";
							UMLClass correlationTable = transformerUtils.findCorrelationTable(association, model, assocKlass);
							String keyColumnName = transformerUtils.findAssociatedColumn(correlationTable,assocKlass,thisEnd, currentKlass,otherEnd, true);
							String assocColumnName = transformerUtils.findAssociatedColumn(correlationTable,currentKlass,otherEnd, assocKlass, thisEnd, true);
							String inverseColumnName =  transformerUtils.findInverseColumnValue(correlationTable,assocKlass,thisEnd);
							if(!"".equals(inverseColumnName) && !assocColumnName.equals(inverseColumnName))
								throw new GenerationException("Different columns used for implements-association and inverse-of of the same association");
							String inverseValue = assocColumnName.equals(inverseColumnName) ?"true":"false";
							String joinTableName = correlationTable.getName();
    stringBuffer.append(TEXT_80);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_81);
    stringBuffer.append(otherEnd.getRoleName());
    stringBuffer.append(TEXT_82);
    stringBuffer.append(joinTableName);
    stringBuffer.append(TEXT_83);
    stringBuffer.append(lazyValue);
    stringBuffer.append(TEXT_84);
    stringBuffer.append(inverseValue);
    stringBuffer.append(TEXT_85);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_86);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_87);
    stringBuffer.append(keyColumnName);
    stringBuffer.append(TEXT_88);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_89);
    stringBuffer.append(assocKlassName);
    stringBuffer.append(TEXT_90);
    stringBuffer.append(assocColumnName);
    stringBuffer.append(TEXT_91);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_92);
    
						}else if(transformerUtils.isOne2Many(thisEnd,otherEnd)){	//One to Many
							String lazyValue = lazy == true ? "true" : "false";
							UMLClass correlationTable = transformerUtils.findCorrelationTable(association, model, assocKlass, false);
							if (correlationTable == null) //One to Many - No Join Table
							{
								UMLClass assocTable = transformerUtils.getTable(assocKlass);
								String notNullFkAttr=transformerUtils.isFKAttributeNull(otherEnd);
								String keyColumnName = transformerUtils.findAssociatedColumn(assocTable,assocKlass,thisEnd,currentKlass,otherEnd, false);
								String assocColumnName = transformerUtils.findAssociatedColumn(assocTable,currentKlass,otherEnd,assocKlass,thisEnd, false);
								String inverseColumnName =  transformerUtils.findInverseColumnValue(assocTable,assocKlass,thisEnd);
								if(!"".equals(inverseColumnName) && !assocColumnName.equals(inverseColumnName))
									throw new GenerationException("Different columns used for 'implements-association' and 'inverse-of' tags of the same association");
								String inverseValue = assocColumnName.equals(inverseColumnName) ?"true":"false"; 
    stringBuffer.append(TEXT_93);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_94);
    stringBuffer.append(otherEnd.getRoleName());
    stringBuffer.append(TEXT_95);
    stringBuffer.append(lazyValue);
    stringBuffer.append(TEXT_96);
    stringBuffer.append(cascadeStyle);
    stringBuffer.append(TEXT_97);
    stringBuffer.append(inverseValue);
    stringBuffer.append(TEXT_98);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_99);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_100);
    stringBuffer.append(keyColumnName);
    stringBuffer.append(TEXT_101);
    stringBuffer.append(notNullFkAttr);
    stringBuffer.append(TEXT_102);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_103);
    stringBuffer.append(assocKlassName);
    stringBuffer.append(TEXT_104);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_105);
    
							}else{ //One to Many - Join Table
								String keyColumnName = transformerUtils.findAssociatedColumn(correlationTable,assocKlass,thisEnd, currentKlass, otherEnd, true);
								String assocColumnName = transformerUtils.findAssociatedColumn(correlationTable,currentKlass,otherEnd,assocKlass,thisEnd, true);
								String inverseColumnName =  transformerUtils.findInverseColumnValue(correlationTable,assocKlass,thisEnd);
								if(!"".equals(inverseColumnName) && !assocColumnName.equals(inverseColumnName))
									throw new GenerationException("Different columns used for 'implements-association' and 'inverse-of' of the same association");
								String inverseValue = assocColumnName.equals(inverseColumnName) ?"true":"false";
								String joinTableName = correlationTable.getName();
    stringBuffer.append(TEXT_106);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_107);
    stringBuffer.append(otherEnd.getRoleName());
    stringBuffer.append(TEXT_108);
    stringBuffer.append(joinTableName);
    stringBuffer.append(TEXT_109);
    stringBuffer.append(lazyValue);
    stringBuffer.append(TEXT_110);
    stringBuffer.append(cascadeStyle);
    stringBuffer.append(TEXT_111);
    stringBuffer.append(inverseValue);
    stringBuffer.append(TEXT_112);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_113);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_114);
    stringBuffer.append(keyColumnName);
    stringBuffer.append(TEXT_115);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_116);
    stringBuffer.append(assocKlassName);
    stringBuffer.append(TEXT_117);
    stringBuffer.append(assocColumnName);
    stringBuffer.append(TEXT_118);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_119);
    
							}
						}else if(transformerUtils.isMany2One(thisEnd,otherEnd)){
								String notNullFkAttr=transformerUtils.isFKAttributeNull(otherEnd);
								UMLClass correlationTable = transformerUtils.findCorrelationTable(association, model, assocKlass, false);
								if (correlationTable == null) //Many to One - No Join Table
								{	
									String lazyValue = lazy == true ? "proxy" : "false";							
									String keyColumnName = transformerUtils.findAssociatedColumn(table,currentKlass,otherEnd,assocKlass,thisEnd, false);
    stringBuffer.append(TEXT_120);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_121);
    stringBuffer.append(otherEnd.getRoleName());
    stringBuffer.append(TEXT_122);
    stringBuffer.append(assocKlassName);
    stringBuffer.append(TEXT_123);
    stringBuffer.append(keyColumnName);
    stringBuffer.append(TEXT_124);
    stringBuffer.append(lazyValue);
    stringBuffer.append(TEXT_125);
    stringBuffer.append(notNullFkAttr);
    stringBuffer.append(TEXT_126);
    stringBuffer.append(cascadeStyle);
    stringBuffer.append(TEXT_127);
    
								}else{ // Many to One - Join Table
						
										// do nothing; do not generate any <join> elements in this first pass!  Hibernate DTD requires any <set> elements to appear first
								}
						}else{	//One to One
							String lazyValue = lazy == true ? "proxy" : "false";
							String notNullFkAttr=transformerUtils.isFKAttributeNull(otherEnd);
							UMLClass correlationTable = transformerUtils.findCorrelationTable(association, model, assocKlass, false);
							if (correlationTable == null) //Many to One - No Join Table
							{

								String keyColumnName = transformerUtils.findAssociatedColumn(table,currentKlass,otherEnd,assocKlass,thisEnd, false, false);
								Boolean keyColumnPresent = (keyColumnName!=null && !"".equals(keyColumnName));
								if(thisEnd.isNavigable())
								{
									if(keyColumnPresent){
    stringBuffer.append(TEXT_128);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_129);
    stringBuffer.append(otherEnd.getRoleName());
    stringBuffer.append(TEXT_130);
    stringBuffer.append(assocKlassName);
    stringBuffer.append(TEXT_131);
    stringBuffer.append(keyColumnName);
    stringBuffer.append(TEXT_132);
    stringBuffer.append(lazyValue);
    stringBuffer.append(TEXT_133);
    stringBuffer.append(notNullFkAttr);
    stringBuffer.append(TEXT_134);
    stringBuffer.append(cascadeStyle);
    stringBuffer.append(TEXT_135);
    
									}else{
    stringBuffer.append(TEXT_136);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_137);
    stringBuffer.append(otherEnd.getRoleName());
    stringBuffer.append(TEXT_138);
    stringBuffer.append(assocKlassName);
    stringBuffer.append(TEXT_139);
    stringBuffer.append(thisEnd.getRoleName());
    stringBuffer.append(TEXT_140);
    stringBuffer.append(lazyValue);
    stringBuffer.append(TEXT_141);
    stringBuffer.append(cascadeStyle);
    stringBuffer.append(TEXT_142);
    
									}
								}else{
									if(keyColumnPresent){
    stringBuffer.append(TEXT_143);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_144);
    stringBuffer.append(otherEnd.getRoleName());
    stringBuffer.append(TEXT_145);
    stringBuffer.append(assocKlassName);
    stringBuffer.append(TEXT_146);
    stringBuffer.append(keyColumnName);
    stringBuffer.append(TEXT_147);
    stringBuffer.append(lazyValue);
    stringBuffer.append(TEXT_148);
    stringBuffer.append(notNullFkAttr);
    stringBuffer.append(TEXT_149);
    stringBuffer.append(cascadeStyle);
    stringBuffer.append(TEXT_150);
    
									}else {
									    throw new GenerationException("One to one unidirectional mapping requires key column to be present in the source class"+transformerUtils.getFQCN(currentKlass));
									}
								}
							}else{ // generate <join> statement
								// do nothing; do not generate any <join> elements in this first pass!  Hibernate DTD requires any <set> elements to appear first
							}
						}
					}
				}//end - for(UMLAssociation association:currentKlass.getAssociations()) - First Pass to process 'set' elements
				
				//Second Pass - process any <join> elements
				for(UMLAssociation association:currentKlass.getAssociations()){
					List<UMLAssociationEnd> assocEnds = association.getAssociationEnds();
					UMLAssociationEnd thisEnd = transformerUtils.getThisEnd(currentKlass,assocEnds);
					UMLAssociationEnd otherEnd = transformerUtils.getOtherEnd(currentKlass,assocEnds);
					
					if(otherEnd.isNavigable())
					{
						UMLClass assocKlass = (UMLClass)otherEnd.getUMLElement();
						String assocKlassName = transformerUtils.getFQCN(assocKlass);
						String cascadeStyle = transformerUtils.findCascadeStyle(currentKlass, otherEnd.getRoleName(), association);
						boolean lazy = transformerUtils.isLazyLoad(currentKlass, otherEnd.getRoleName(), association);
						
				        if(transformerUtils.isMany2One(thisEnd,otherEnd)){
								String notNullFkAttr=transformerUtils.isFKAttributeNull(otherEnd);
								UMLClass correlationTable = transformerUtils.findCorrelationTable(association, model, assocKlass, false);
								if (correlationTable != null) //Many to One -  Join Table
								{
									String lazyValue = lazy == true ? "proxy" : "false";
									String keyColumnName = transformerUtils.findAssociatedColumn(correlationTable,assocKlass,thisEnd, currentKlass, otherEnd, true);
									String assocColumnName = transformerUtils.findAssociatedColumn(correlationTable,currentKlass,otherEnd,assocKlass,thisEnd, true);
									String inverseColumnName =  transformerUtils.findInverseColumnValue(correlationTable,assocKlass,thisEnd);
									if(!"".equals(inverseColumnName) && !assocColumnName.equals(inverseColumnName))
										throw new GenerationException("Different columns used for 'implements-association' and 'inverse-of' of the same association");
									String inverseValue = assocColumnName.equals(inverseColumnName) ?"true":"false";
									String joinTableName = correlationTable.getName();
    stringBuffer.append(TEXT_151);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_152);
    stringBuffer.append(joinTableName);
    stringBuffer.append(TEXT_153);
    stringBuffer.append(inverseValue);
    stringBuffer.append(TEXT_154);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_155);
    stringBuffer.append(keyColumnName);
    stringBuffer.append(TEXT_156);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_157);
    stringBuffer.append(otherEnd.getRoleName());
    stringBuffer.append(TEXT_158);
    stringBuffer.append(assocColumnName);
    stringBuffer.append(TEXT_159);
    stringBuffer.append(assocKlassName);
    stringBuffer.append(TEXT_160);
    stringBuffer.append(lazyValue);
    stringBuffer.append(TEXT_161);
    stringBuffer.append(notNullFkAttr);
    stringBuffer.append(TEXT_162);
    stringBuffer.append(cascadeStyle);
    stringBuffer.append(TEXT_163);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_164);
    
								}
						}else if(transformerUtils.isOne2One(thisEnd,otherEnd)){	//One to One
							String lazyValue = lazy == true ? "proxy" : "false";
							String notNullFkAttr=transformerUtils.isFKAttributeNull(otherEnd);
							UMLClass correlationTable = transformerUtils.findCorrelationTable(association, model, assocKlass, false);
							if (correlationTable != null) //Many to One -  Join Table
							{
								String keyColumnName = transformerUtils.findAssociatedColumn(correlationTable,assocKlass,thisEnd, currentKlass, otherEnd, true);
								String assocColumnName = transformerUtils.findAssociatedColumn(correlationTable,currentKlass,otherEnd,assocKlass,thisEnd, true);
								String inverseColumnName =  transformerUtils.findInverseColumnValue(correlationTable,assocKlass,thisEnd);
								if(!"".equals(inverseColumnName) && !assocColumnName.equals(inverseColumnName))
									throw new GenerationException("Different columns used for 'implements-association' and 'inverse-of' of the same association");
								String inverseValue = assocColumnName.equals(inverseColumnName) ?"true":"false";
								String joinTableName = correlationTable.getName();
    stringBuffer.append(TEXT_165);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_166);
    stringBuffer.append(joinTableName);
    stringBuffer.append(TEXT_167);
    stringBuffer.append(inverseValue);
    stringBuffer.append(TEXT_168);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_169);
    stringBuffer.append(keyColumnName);
    stringBuffer.append(TEXT_170);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_171);
    stringBuffer.append(otherEnd.getRoleName());
    stringBuffer.append(TEXT_172);
    stringBuffer.append(assocColumnName);
    stringBuffer.append(TEXT_173);
    stringBuffer.append(assocKlassName);
    stringBuffer.append(TEXT_174);
    stringBuffer.append(lazyValue);
    stringBuffer.append(TEXT_175);
    stringBuffer.append(notNullFkAttr);
    stringBuffer.append(TEXT_176);
    stringBuffer.append(cascadeStyle);
    stringBuffer.append(TEXT_177);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_178);
    
							}
						}
					}
				}//end - for(UMLAssociation association:currentKlass.getAssociations()) - Second Pass to process 'join' elements
				
			}//end -  if(currentKlass.getAssociations().size()>0
			
			currentKlass = transformerUtils.getSuperClass(currentKlass);
		}while(currentKlass!=null && transformerUtils.isImplicitParent(currentKlass));
		for(UMLGeneralization gen:klass.getGeneralizations()){
			UMLClass subKlass = (UMLClass)gen.getSubtype();
			String subFqcn = transformerUtils.getFQCN(subKlass);
			if(subKlass!=klass){
				if(discriminatorColumnName == null || "".equals(discriminatorColumnName)){
				UMLClass superKlass = (UMLClass)gen.getSupertype();
				UMLClass subTable = transformerUtils.getTable(subKlass);
				String keyColumnName = transformerUtils.getMappedColumnName(subTable,subFqcn+"."+idAttr.getName());
    stringBuffer.append(TEXT_179);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_180);
    stringBuffer.append(subFqcn);
    stringBuffer.append(TEXT_181);
    stringBuffer.append(subTable.getName());
    stringBuffer.append(TEXT_182);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_183);
    stringBuffer.append(keyColumnName);
    stringBuffer.append(TEXT_184);
    stringBuffer.append(generate(model, subKlass, level+1));
    stringBuffer.append(TEXT_185);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_186);
    
				}else{
					String discriminatorValue = transformerUtils.getDiscriminatorValue(subKlass);
					UMLClass subTable = transformerUtils.getTable(subKlass);
					if(subTable == table){
    stringBuffer.append(TEXT_187);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_188);
    stringBuffer.append(subFqcn);
    stringBuffer.append(TEXT_189);
    stringBuffer.append(discriminatorValue);
    stringBuffer.append(TEXT_190);
    stringBuffer.append(generate(model, subKlass, level+1));
    stringBuffer.append(TEXT_191);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_192);
    
					}else{
						String keyColumnName = transformerUtils.getMappedColumnName(subTable,subFqcn+"."+idAttr.getName());
    stringBuffer.append(TEXT_193);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_194);
    stringBuffer.append(subFqcn);
    stringBuffer.append(TEXT_195);
    stringBuffer.append(discriminatorValue);
    stringBuffer.append(TEXT_196);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_197);
    stringBuffer.append(subTable.getName());
    stringBuffer.append(TEXT_198);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_199);
    stringBuffer.append(keyColumnName);
    stringBuffer.append(TEXT_200);
    stringBuffer.append(generate(model, subKlass, level+1));
    stringBuffer.append(TEXT_201);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_202);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_203);
    
					}
				}
			}
		}
    if(level == 0){
    stringBuffer.append(TEXT_204);
    }
    return stringBuffer.toString();
  }
}