package gov.nih.nci.codegen.transformer.jet;

import gov.nih.nci.codegen.transformer.UMLClassJetTransformer;
import gov.nih.nci.codegen.Artifact;
import gov.nih.nci.codegen.artifact.BaseArtifact;
import gov.nih.nci.codegen.util.TransformerUtils;
import gov.nih.nci.codegen.GenerationException;

import gov.nih.nci.ncicb.xmiinout.domain.UMLModel;
import gov.nih.nci.ncicb.xmiinout.domain.UMLClass;
import gov.nih.nci.ncicb.xmiinout.domain.UMLAttribute;
import gov.nih.nci.ncicb.xmiinout.domain.UMLAssociation;
import gov.nih.nci.ncicb.xmiinout.domain.UMLAssociationEnd;

import java.util.List;

public class POJOTransformer extends UMLClassJetTransformer{

  protected final String NL = System.getProperties().getProperty("line.separator");
  protected final String TEXT_1 = "package ";
  protected final String TEXT_2 = ";" + NL;
  protected final String TEXT_3 = NL;
  protected final String TEXT_4 = NL + "import java.io.Serializable;";
  protected final String TEXT_5 = NL;
  protected final String TEXT_6 = NL;
  protected final String TEXT_7 = NL + "public";
  protected final String TEXT_8 = " class ";
  protected final String TEXT_9 = " ";
  protected final String TEXT_10 = " implements Serializable";
  protected final String TEXT_11 = NL + "{" + NL + "\t/**" + NL + "\t* An attribute to allow serialization of the domain objects" + NL + "\t*/" + NL + "\tprivate static final long serialVersionUID = 1234567890L;" + NL + "" + NL + "\t";
  protected final String TEXT_12 = NL + "\t";
  protected final String TEXT_13 = NL + "\t";
  protected final String TEXT_14 = NL + "\t";
  protected final String TEXT_15 = " ";
  protected final String TEXT_16 = " ";
  protected final String TEXT_17 = ";" + NL + "\t";
  protected final String TEXT_18 = NL + "\tpublic ";
  protected final String TEXT_19 = " ";
  protected final String TEXT_20 = "(){" + NL + "\t\treturn ";
  protected final String TEXT_21 = ";" + NL + "\t}" + NL + "" + NL + "\t";
  protected final String TEXT_22 = NL + "\tpublic void ";
  protected final String TEXT_23 = "(";
  protected final String TEXT_24 = " ";
  protected final String TEXT_25 = "){" + NL + "\t\tthis.";
  protected final String TEXT_26 = " = ";
  protected final String TEXT_27 = ";" + NL + "\t}" + NL + "\t";
  protected final String TEXT_28 = NL + "\t";
  protected final String TEXT_29 = "\t\t\t" + NL + "\tprivate Collection<";
  protected final String TEXT_30 = "> ";
  protected final String TEXT_31 = ";" + NL + "\t";
  protected final String TEXT_32 = NL + "\tpublic Collection<";
  protected final String TEXT_33 = "> ";
  protected final String TEXT_34 = "(){" + NL + "\t\treturn ";
  protected final String TEXT_35 = ";" + NL + "\t}" + NL + "" + NL + "\t";
  protected final String TEXT_36 = NL + "\tpublic void ";
  protected final String TEXT_37 = "(Collection<";
  protected final String TEXT_38 = "> ";
  protected final String TEXT_39 = "){" + NL + "\t\tthis.";
  protected final String TEXT_40 = " = ";
  protected final String TEXT_41 = ";" + NL + "\t}" + NL + "\t\t";
  protected final String TEXT_42 = NL + "\t";
  protected final String TEXT_43 = "\t\t\t" + NL + "\tprivate ";
  protected final String TEXT_44 = " ";
  protected final String TEXT_45 = ";" + NL + "\t";
  protected final String TEXT_46 = "\t" + NL + "\tpublic ";
  protected final String TEXT_47 = " ";
  protected final String TEXT_48 = "(){" + NL + "\t\treturn ";
  protected final String TEXT_49 = ";" + NL + "\t}" + NL + "\t";
  protected final String TEXT_50 = NL + "\tpublic void ";
  protected final String TEXT_51 = "(";
  protected final String TEXT_52 = " ";
  protected final String TEXT_53 = "){" + NL + "\t\tthis.";
  protected final String TEXT_54 = " = ";
  protected final String TEXT_55 = ";" + NL + "\t}" + NL + "\t\t\t";
  protected final String TEXT_56 = NL + "\t/**" + NL + "\t* Compares <code>obj</code> to it self and returns true if they both are same" + NL + "\t*" + NL + "\t* @param obj" + NL + "\t**/" + NL + "\tpublic boolean equals(Object obj)" + NL + "\t{" + NL + "\t\tif(obj instanceof ";
  protected final String TEXT_57 = ") " + NL + "\t\t{" + NL + "\t\t\t";
  protected final String TEXT_58 = " c =(";
  protected final String TEXT_59 = ")obj; \t\t\t " + NL + "\t\t\tif(";
  protected final String TEXT_60 = "() != null && ";
  protected final String TEXT_61 = "().equals(c.";
  protected final String TEXT_62 = "()))" + NL + "\t\t\t\treturn true;" + NL + "\t\t}" + NL + "\t\treturn false;" + NL + "\t}" + NL + "\t\t" + NL + "\t/**" + NL + "\t* Returns hash code for the primary key of the object" + NL + "\t**/" + NL + "\tpublic int hashCode()" + NL + "\t{" + NL + "\t\tif(";
  protected final String TEXT_63 = "() != null)" + NL + "\t\t\treturn ";
  protected final String TEXT_64 = "().hashCode();" + NL + "\t\treturn 0;" + NL + "\t}" + NL + "\t";
  protected final String TEXT_65 = NL + "}";

	public Artifact executeTemplate(UMLModel model, UMLClass klass) throws GenerationException{
		BaseArtifact artifact = new BaseArtifact(transformerUtils);
		artifact.setContent(generate(model, klass));
		artifact.createSourceName(klass);
		return artifact;
	}
	
	public String generate(UMLModel model, UMLClass klass)  throws GenerationException
  {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(TEXT_1);
    stringBuffer.append(transformerUtils.getFullPackageName(klass));
    stringBuffer.append(TEXT_2);
    stringBuffer.append(TEXT_3);
    stringBuffer.append(transformerUtils.getImports(klass));
    stringBuffer.append(TEXT_4);
    stringBuffer.append(TEXT_5);
    stringBuffer.append(transformerUtils.getJavaDocs(klass));
    stringBuffer.append(TEXT_6);
    stringBuffer.append(transformerUtils.getHibernateValidatorConstraints(klass));
    stringBuffer.append(TEXT_7);
    stringBuffer.append(transformerUtils.isAbstract(klass)? " abstract" : "" );
    stringBuffer.append(TEXT_8);
    stringBuffer.append(klass.getName());
    stringBuffer.append(TEXT_9);
    stringBuffer.append(transformerUtils.getSuperClassString(klass));
    stringBuffer.append(TEXT_10);
    stringBuffer.append(transformerUtils.getInterfaceString(klass));
    stringBuffer.append(TEXT_11);
    for(UMLAttribute attr:klass.getAttributes()){
    stringBuffer.append(TEXT_12);
    stringBuffer.append(transformerUtils.getJavaDocs(attr));
    stringBuffer.append(TEXT_13);
    stringBuffer.append(transformerUtils.getHibernateValidatorConstraints(klass,attr));
    stringBuffer.append(TEXT_14);
    stringBuffer.append(attr.getVisibility().getName());
    stringBuffer.append(TEXT_15);
    stringBuffer.append(transformerUtils.getDataType(attr));
    stringBuffer.append(TEXT_16);
    stringBuffer.append(attr.getName());
    stringBuffer.append(TEXT_17);
    stringBuffer.append(transformerUtils.getGetterMethodJavaDocs(attr));
    stringBuffer.append(TEXT_18);
    stringBuffer.append(transformerUtils.getDataType(attr));
    stringBuffer.append(TEXT_19);
    stringBuffer.append(transformerUtils.getGetterMethodName(attr));
    stringBuffer.append(TEXT_20);
    stringBuffer.append(attr.getName());
    stringBuffer.append(TEXT_21);
    stringBuffer.append(transformerUtils.getSetterMethodJavaDocs(attr));
    stringBuffer.append(TEXT_22);
    stringBuffer.append(transformerUtils.getSetterMethodName(attr));
    stringBuffer.append(TEXT_23);
    stringBuffer.append(transformerUtils.getDataType(attr));
    stringBuffer.append(TEXT_24);
    stringBuffer.append(attr.getName());
    stringBuffer.append(TEXT_25);
    stringBuffer.append(attr.getName());
    stringBuffer.append(TEXT_26);
    stringBuffer.append(attr.getName());
    stringBuffer.append(TEXT_27);
    }
	for(UMLAssociation assoc:klass.getAssociations()){
		List<UMLAssociationEnd> assocEnds = assoc.getAssociationEnds();
		UMLAssociationEnd thisEnd = transformerUtils.getThisEnd(klass,assocEnds);
		UMLAssociationEnd otherEnd = transformerUtils.getOtherEnd(klass,assocEnds);
	
		if(otherEnd.isNavigable())
		{
			UMLClass assocKlass = (UMLClass)otherEnd.getUMLElement();
			if(transformerUtils.isAssociationEndMany(otherEnd))
			{
    stringBuffer.append(TEXT_28);
    stringBuffer.append(transformerUtils.getJavaDocs(klass, assoc));
    stringBuffer.append(TEXT_29);
    stringBuffer.append(assocKlass.getName());
    stringBuffer.append(TEXT_30);
    stringBuffer.append(otherEnd.getRoleName());
    stringBuffer.append(TEXT_31);
    stringBuffer.append(transformerUtils.getGetterMethodJavaDocs(klass, assoc));
    stringBuffer.append(TEXT_32);
    stringBuffer.append(assocKlass.getName());
    stringBuffer.append(TEXT_33);
    stringBuffer.append(transformerUtils.getGetterMethodName(otherEnd));
    stringBuffer.append(TEXT_34);
    stringBuffer.append(otherEnd.getRoleName());
    stringBuffer.append(TEXT_35);
    stringBuffer.append(transformerUtils.getSetterMethodJavaDocs(klass, assoc));
    stringBuffer.append(TEXT_36);
    stringBuffer.append(transformerUtils.getSetterMethodName(otherEnd));
    stringBuffer.append(TEXT_37);
    stringBuffer.append(assocKlass.getName());
    stringBuffer.append(TEXT_38);
    stringBuffer.append(otherEnd.getRoleName());
    stringBuffer.append(TEXT_39);
    stringBuffer.append(otherEnd.getRoleName());
    stringBuffer.append(TEXT_40);
    stringBuffer.append(otherEnd.getRoleName());
    stringBuffer.append(TEXT_41);
    }else{
    stringBuffer.append(TEXT_42);
    stringBuffer.append(transformerUtils.getJavaDocs(klass, assoc));
    stringBuffer.append(TEXT_43);
    stringBuffer.append(assocKlass.getName());
    stringBuffer.append(TEXT_44);
    stringBuffer.append(otherEnd.getRoleName());
    stringBuffer.append(TEXT_45);
    stringBuffer.append(transformerUtils.getGetterMethodJavaDocs(klass, assoc));
    stringBuffer.append(TEXT_46);
    stringBuffer.append(assocKlass.getName());
    stringBuffer.append(TEXT_47);
    stringBuffer.append(transformerUtils.getGetterMethodName(otherEnd));
    stringBuffer.append(TEXT_48);
    stringBuffer.append(otherEnd.getRoleName());
    stringBuffer.append(TEXT_49);
    stringBuffer.append(transformerUtils.getSetterMethodJavaDocs(klass, assoc));
    stringBuffer.append(TEXT_50);
    stringBuffer.append(transformerUtils.getSetterMethodName(otherEnd));
    stringBuffer.append(TEXT_51);
    stringBuffer.append(assocKlass.getName());
    stringBuffer.append(TEXT_52);
    stringBuffer.append(otherEnd.getRoleName());
    stringBuffer.append(TEXT_53);
    stringBuffer.append(otherEnd.getRoleName());
    stringBuffer.append(TEXT_54);
    stringBuffer.append(otherEnd.getRoleName());
    stringBuffer.append(TEXT_55);
    }
		}
	}

	String idGetter = transformerUtils.getClassIdGetterMthod(klass); 
	if(idGetter!=null){
    stringBuffer.append(TEXT_56);
    stringBuffer.append(klass.getName() );
    stringBuffer.append(TEXT_57);
    stringBuffer.append(klass.getName() );
    stringBuffer.append(TEXT_58);
    stringBuffer.append(klass.getName());
    stringBuffer.append(TEXT_59);
    stringBuffer.append(idGetter);
    stringBuffer.append(TEXT_60);
    stringBuffer.append(idGetter);
    stringBuffer.append(TEXT_61);
    stringBuffer.append(idGetter);
    stringBuffer.append(TEXT_62);
    stringBuffer.append(idGetter);
    stringBuffer.append(TEXT_63);
    stringBuffer.append(idGetter);
    stringBuffer.append(TEXT_64);
    }
    stringBuffer.append(TEXT_65);
    return stringBuffer.toString();
  }
}