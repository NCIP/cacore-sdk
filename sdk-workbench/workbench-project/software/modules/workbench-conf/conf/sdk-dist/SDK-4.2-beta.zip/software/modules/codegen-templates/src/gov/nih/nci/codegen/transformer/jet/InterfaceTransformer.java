package gov.nih.nci.codegen.transformer.jet;

import gov.nih.nci.codegen.transformer.UMLInterfaceJetTransformer;
import gov.nih.nci.codegen.Artifact;
import gov.nih.nci.codegen.artifact.BaseArtifact;
import gov.nih.nci.codegen.util.TransformerUtils;
import gov.nih.nci.codegen.GenerationException;

import gov.nih.nci.ncicb.xmiinout.domain.UMLModel;
import gov.nih.nci.ncicb.xmiinout.domain.UMLInterface;
import gov.nih.nci.ncicb.xmiinout.domain.UMLAttribute;
import gov.nih.nci.ncicb.xmiinout.domain.UMLAssociation;
import gov.nih.nci.ncicb.xmiinout.domain.UMLAssociationEnd;

import java.util.List;

public class InterfaceTransformer extends UMLInterfaceJetTransformer{

  protected final String NL = System.getProperties().getProperty("line.separator");
  protected final String TEXT_1 = "package ";
  protected final String TEXT_2 = ";" + NL;
  protected final String TEXT_3 = NL;
  protected final String TEXT_4 = NL;
  protected final String TEXT_5 = " " + NL + "public interface ";
  protected final String TEXT_6 = " ";
  protected final String TEXT_7 = NL + "{" + NL + "\t/**" + NL + "\t* This is a Marker Interface without any behavior" + NL + "\t*/" + NL + "" + NL + "}";

	public Artifact executeTemplate(UMLModel model, UMLInterface interfaze) throws GenerationException{
		BaseArtifact artifact = new BaseArtifact(transformerUtils);
		artifact.setContent(generate(model, interfaze));
		artifact.createSourceName(interfaze);
		return artifact;
	}
	
	public String generate(UMLModel model, UMLInterface interfaze)  throws GenerationException
  {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(TEXT_1);
    stringBuffer.append(transformerUtils.getFullPackageName(interfaze));
    stringBuffer.append(TEXT_2);
    stringBuffer.append(TEXT_3);
    stringBuffer.append(transformerUtils.getInterfaceImports(interfaze));
    stringBuffer.append(TEXT_4);
    stringBuffer.append(transformerUtils.getJavaDocs(interfaze));
    stringBuffer.append(TEXT_5);
    stringBuffer.append(interfaze.getName());
    stringBuffer.append(TEXT_6);
    stringBuffer.append(transformerUtils.getSuperInterfaceString(interfaze));
    stringBuffer.append(TEXT_7);
    return stringBuffer.toString();
  }
}