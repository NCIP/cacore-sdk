package gov.nih.nci.codegen.transformer.jet;

import gov.nih.nci.codegen.transformer.UMLModelJETTransformer;
import gov.nih.nci.codegen.Artifact;
import gov.nih.nci.codegen.artifact.BaseArtifact;
import gov.nih.nci.codegen.util.TransformerUtils;
import gov.nih.nci.codegen.GenerationException;

import gov.nih.nci.ncicb.xmiinout.domain.UMLModel;
import gov.nih.nci.ncicb.xmiinout.domain.UMLClass;
import gov.nih.nci.ncicb.xmiinout.domain.UMLAssociation;
import gov.nih.nci.ncicb.xmiinout.domain.UMLAssociationEnd;
import gov.nih.nci.ncicb.xmiinout.domain.UMLAttribute;

import java.util.Collection;
import java.util.List;
import java.util.Map;

public class CLMLoggerCfgTransformer extends UMLModelJETTransformer{

	  protected final String NL = System.getProperties().getProperty("line.separator");
  protected final String TEXT_1 = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + NL + "<!DOCTYPE ObjectStateLoggerConfig [" + NL + "<!-- " + NL + "\tObjectStateLoggerConfig DTD. This DTD is specified for the ObjectStateLoggerConfig.xml" + NL + "-->" + NL + "<!ELEMENT ObjectStateLoggerConfig (ObjectStateLoggerName, LoggerConfigurationFile, LogLevel, LoggingEnabled, ObjectStateLoggerMessageFormat, DomainObjectList)>" + NL + "<!--" + NL + "\tName of the Logger used in the LoggerConfigurationFile." + NL + "\tThe name of the logger should match with the log4j-config.xml logger value. That is, log4j-config.xml " + NL + "\tshould have a logger with ObjectStateLoggerName." + NL + "-->" + NL + "<!ELEMENT ObjectStateLoggerName (#PCDATA)>" + NL + "<!--" + NL + "Name of the Log4j Config file. Example: sample-log4j-config.xml" + NL + "-->" + NL + "<!ELEMENT LoggerConfigurationFile (#PCDATA)>" + NL + "<!--" + NL + "\tLogLevel indicates the log level to be logged. Possible values are the Log4j Log Levels specified in org.apache.log4j.Level." + NL + "\tCheck the class for all possible values. Example values are OFF, FATAL, ERROR, WARN, INFODEBUG and ALL." + NL + "-->" + NL + "<!ELEMENT LogLevel (#PCDATA)>" + NL + "<!--" + NL + "\tLoggingEnabled. Enable or Disable logging." + NL + "\tTrue - indicates logging is enabled." + NL + "-->" + NL + "<!ELEMENT LoggingEnabled (#PCDATA)>" + NL + "<!ATTLIST  LoggingEnabled value (true | false) \"true\">" + NL + "<!--" + NL + "\tObjectStateLoggerMessageFormat indicates the type of message. ie. string, etc." + NL + "\tDefault value is string." + NL + "-->" + NL + "<!ELEMENT ObjectStateLoggerMessageFormat EMPTY>" + NL + "<!ATTLIST  ObjectStateLoggerMessageFormat type (string|xml) \"string\">" + NL + "<!--" + NL + "\tDomainObjectList is the list of DomainObjects whose state changes are to be logged." + NL + "-->" + NL + "<!ELEMENT DomainObjectList (DomainObject)*>" + NL + "<!--" + NL + "\tDomainObject whose state changes are to be logged." + NL + "-->" + NL + "<!ELEMENT DomainObject (ObjectName, IdentifierAttribute?)>" + NL + "<!-- " + NL + "\tObjectName of the domain object. Example: sample.package.ClassName" + NL + "-->" + NL + "<!ELEMENT ObjectName (#PCDATA)>" + NL + "<!-- " + NL + "\tIdentifierAttribute is the name of the object property that is to be used save in logs object ID column. This value will be matched with " + NL + "\tquery Object ID for retrieval. " + NL + "\tExample: For object with attributes: personname, street, zip. < IdentifierAttribute>personname</ IdentifierAttribute>." + NL + "\t In this example, the attribute 'personname' will be used to store logs with ObjectId = Name" + NL + "" + NL + "\tExample: For object with attributes: first, last, street, zip. <IdentifierAttribute>first,last</ IdentifierAttribute>. " + NL + "\tIn this example, the composite attributes value of 'first+last' will used to store logs with ObjectID = 'first+last'." + NL + "-->" + NL + "<!ELEMENT IdentifierAttribute (#PCDATA)>" + NL + "" + NL + "" + NL + "]>" + NL + "<ObjectStateLoggerConfig>" + NL + "\t<ObjectStateLoggerName>CSM.Audit.Logging.ObjectState.Authorization</ObjectStateLoggerName>" + NL + "\t<LoggerConfigurationFile>log4j.xml</LoggerConfigurationFile>" + NL + "\t<LogLevel>info</LogLevel>" + NL + "\t<LoggingEnabled value=\"true\" />" + NL + "\t<ObjectStateLoggerMessageFormat type=\"string\" />" + NL + "\t<DomainObjectList>";
  protected final String TEXT_2 = NL + "\t\t<DomainObject>" + NL + "\t\t\t<ObjectName>";
  protected final String TEXT_3 = "</ObjectName>" + NL + "\t\t\t<IdentifierAttribute>";
  protected final String TEXT_4 = "</IdentifierAttribute>" + NL + "\t\t</DomainObject>\t";
  protected final String TEXT_5 = NL + "\t</DomainObjectList>" + NL + "</ObjectStateLoggerConfig>";

public Artifact executeTemplate(UMLModel model, Map<String, Object> configurationParams) throws GenerationException{
		BaseArtifact artifact = new BaseArtifact(transformerUtils);
		artifact.setContent(generate(model, configurationParams));
		return artifact;
	}
	
	public String generate(UMLModel model, Map configurationParams) throws GenerationException
  {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(TEXT_1);
    for(UMLClass klass:transformerUtils.getAllClasses(model)){
		UMLAttribute idAttr = transformerUtils.getClassIdAttr(klass);
		if (idAttr!=null){
    stringBuffer.append(TEXT_2);
    stringBuffer.append(transformerUtils.getFQCN(klass));
    stringBuffer.append(TEXT_3);
    stringBuffer.append(idAttr.getName());
    stringBuffer.append(TEXT_4);
    		}
	}
    stringBuffer.append(TEXT_5);
    return stringBuffer.toString();
  }
}