package gov.nih.nci.codegen.validator.transformer.jet;

import gov.nih.nci.codegen.transformer.UMLValidatorJETTransformer;
import gov.nih.nci.codegen.Artifact;
import gov.nih.nci.codegen.artifact.BaseArtifact;
import gov.nih.nci.codegen.util.TransformerUtils;
import gov.nih.nci.codegen.GenerationException;

import gov.nih.nci.ncicb.xmiinout.domain.UMLModel;
import gov.nih.nci.ncicb.xmiinout.domain.UMLClass;
import gov.nih.nci.ncicb.xmiinout.domain.UMLAttribute;
import gov.nih.nci.ncicb.xmiinout.domain.UMLAssociation;
import gov.nih.nci.ncicb.xmiinout.domain.UMLAssociationEnd;

import java.util.Collection;
import java.util.List;
import java.util.Map;

public class ValidatorTransformer extends UMLValidatorJETTransformer {
	
	  protected final String NL = System.getProperties().getProperty("line.separator");
  protected final String TEXT_1 = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + NL + "<!DOCTYPE beans PUBLIC \"-//SPRING//DTD BEAN//EN\" \"http://www.springframework.org/dtd/spring-beans.dtd\">" + NL + "<beans default-lazy-init=\"false\" default-dependency-check=\"none\"" + NL + "\tdefault-autowire=\"no\">" + NL + "" + NL + "\t<bean name=\"ValidatorModel\" class=\"gov.nih.nci.codegen.validator.ValidatorModel\">" + NL + "\t\t<constructor-arg>" + NL + "\t\t\t<map>";
  protected final String TEXT_2 = "\t\t\t" + NL + "\t\t\t\t<entry key=\"";
  protected final String TEXT_3 = "\">" + NL + "\t\t\t\t\t<bean class=\"gov.nih.nci.codegen.validator.ValidatorClass\">" + NL + "\t\t\t\t\t\t<constructor-arg value=\"";
  protected final String TEXT_4 = "\" />" + NL + "\t\t\t\t\t\t<constructor-arg index=\"1\"> <!-- attribute-level constraints -->" + NL + "\t\t\t\t\t\t\t<map>";
  protected final String TEXT_5 = NL + "\t\t\t\t\t\t\t\t<entry key=\"";
  protected final String TEXT_6 = "\">" + NL + "\t\t\t\t\t\t\t\t\t<bean class=\"gov.nih.nci.codegen.validator.ValidatorAttribute\">" + NL + "\t\t\t\t\t\t\t\t\t\t<constructor-arg value=\"";
  protected final String TEXT_7 = "\" />" + NL + "\t\t\t\t\t\t\t\t\t\t<constructor-arg index=\"1\">" + NL + "\t\t\t\t\t\t\t\t\t\t\t<list>" + NL + "\t\t\t\t\t\t\t\t\t\t\t\t<bean class=\"gov.nih.nci.codegen.validator.ValidatorConstraint\">" + NL + "\t\t\t\t\t\t\t\t\t\t\t\t\t<constructor-arg value=\"org.hibernate.validator.Pattern\" />" + NL + "\t\t\t\t\t\t\t\t\t\t\t\t\t<constructor-arg index=\"1\">" + NL + "\t\t\t\t\t\t\t\t\t\t\t\t\t\t<map>" + NL + "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<entry key=\"regex\" value='\"(";
  protected final String TEXT_8 = ")\"' />" + NL + "\t\t\t\t\t\t\t\t\t\t\t\t\t\t</map>" + NL + "\t\t\t\t\t\t\t\t\t\t\t\t\t</constructor-arg>" + NL + "\t\t\t\t\t\t\t\t\t\t\t\t</bean>" + NL + "\t\t\t\t\t\t\t\t\t\t\t</list>" + NL + "\t\t\t\t\t\t\t\t\t\t</constructor-arg>" + NL + "\t\t\t\t\t\t\t\t\t</bean>" + NL + "\t\t\t\t\t\t\t\t</entry>\t";
  protected final String TEXT_9 = "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" + NL + "\t\t\t\t\t\t\t</map>" + NL + "\t\t\t\t\t\t</constructor-arg>" + NL + "\t\t\t\t\t\t<constructor-arg index=\"2\"><!-- class-level constraints -->" + NL + "\t\t\t\t\t\t\t<list/>" + NL + "\t\t\t\t\t\t</constructor-arg>\t\t\t\t\t\t" + NL + "\t\t\t\t\t</bean>" + NL + "\t\t\t\t</entry>";
  protected final String TEXT_10 = "\t\t\t\t" + NL + "\t\t\t</map>" + NL + "\t\t</constructor-arg>" + NL + "\t</bean>" + NL + "" + NL + "</beans>" + NL;
  protected final String TEXT_11 = NL + "        ";

public Artifact executeTemplate(UMLModel model, Map<String, Object> configurationParams) throws GenerationException{
		BaseArtifact artifact = new BaseArtifact(transformerUtils);
		artifact.setContent(generate(model, configurationParams));
		return artifact;
	}
	
	public String generate(UMLModel model, Map configurationParams) throws GenerationException
  {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(TEXT_1);
    String enumValues;
boolean addClassConfigBegin = false;
boolean addClassConfigEnd = false;
for(UMLClass klass:transformerUtils.getAllHibernateClasses(model)){

	addClassConfigBegin = true;
	for(UMLAttribute attr: klass.getAttributes()){
		enumValues = getCaDSREnumPattern(transformerUtils.getFQCN(klass)+"."+attr.getName());
		if (enumValues != null && enumValues.length() > 0 ){
			addClassConfigEnd = true;
			if (addClassConfigBegin) { 
    stringBuffer.append(TEXT_2);
    stringBuffer.append(transformerUtils.getFQCN(klass));
    stringBuffer.append(TEXT_3);
    stringBuffer.append(transformerUtils.getFQCN(klass));
    stringBuffer.append(TEXT_4);
    			} 
    stringBuffer.append(TEXT_5);
    stringBuffer.append(attr.getName());
    stringBuffer.append(TEXT_6);
    stringBuffer.append(attr.getName());
    stringBuffer.append(TEXT_7);
    stringBuffer.append(enumValues);
    stringBuffer.append(TEXT_8);
    			if (addClassConfigBegin) 
				addClassConfigBegin = false;
		} //if (enumValues != null && enumValues.length() > 0 )
	} // for(UMLAttribute attr: klass.getAttributes()) 
	if (addClassConfigEnd){
    stringBuffer.append(TEXT_9);
    		addClassConfigEnd = false;
	}	
}
    stringBuffer.append(TEXT_10);
    stringBuffer.append(TEXT_11);
    return stringBuffer.toString();
  }
}