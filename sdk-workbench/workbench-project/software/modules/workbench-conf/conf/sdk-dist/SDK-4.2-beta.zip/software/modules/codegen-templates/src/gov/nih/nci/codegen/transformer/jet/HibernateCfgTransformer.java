package gov.nih.nci.codegen.transformer.jet;

import gov.nih.nci.codegen.transformer.UMLModelJETTransformer;
import gov.nih.nci.codegen.Artifact;
import gov.nih.nci.codegen.artifact.BaseArtifact;
import gov.nih.nci.codegen.util.TransformerUtils;
import gov.nih.nci.codegen.GenerationException;

import gov.nih.nci.ncicb.xmiinout.domain.UMLModel;
import gov.nih.nci.ncicb.xmiinout.domain.UMLClass;
import gov.nih.nci.ncicb.xmiinout.domain.UMLAssociation;
import gov.nih.nci.ncicb.xmiinout.domain.UMLAssociationEnd;
import gov.nih.nci.ncicb.xmiinout.domain.UMLAttribute;

import java.util.Collection;
import java.util.List;
import java.util.Map;

public class HibernateCfgTransformer extends UMLModelJETTransformer{

	  protected final String NL = System.getProperties().getProperty("line.separator");
  protected final String TEXT_1 = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + NL + "<!DOCTYPE hibernate-configuration PUBLIC \"-//Hibernate/Hibernate Configuration DTD 3.0//EN\" \"http://hibernate.sourceforge.net/hibernate-configuration-3.0.dtd\">" + NL + "<hibernate-configuration>" + NL + "\t<session-factory>" + NL + "\t";
  protected final String TEXT_2 = NL + "\t\t<!-- Properties for the session factory -->";
  protected final String TEXT_3 = NL + "\t\t<!--";
  protected final String TEXT_4 = "-->";
  protected final String TEXT_5 = NL + "\t\t<property name=\"";
  protected final String TEXT_6 = "\">";
  protected final String TEXT_7 = "</property>";
  protected final String TEXT_8 = NL + NL + "\t\t<!-- Mapped Resources -->";
  protected final String TEXT_9 = NL + "\t\t<mapping resource=\"";
  protected final String TEXT_10 = ".hbm.xml\" />";
  protected final String TEXT_11 = NL + "\t</session-factory>" + NL + "</hibernate-configuration>" + NL;
  protected final String TEXT_12 = NL + "        ";

public Artifact executeTemplate(UMLModel model, Map<String, Object> configurationParams) throws GenerationException{
		BaseArtifact artifact = new BaseArtifact(transformerUtils);
		artifact.setContent(generate(model, configurationParams));
		return artifact;
	}
	
	public String generate(UMLModel model, Map configurationParams) throws GenerationException
  {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(TEXT_1);
    
	Map hibernatePropertiesMap = (Map)configurationParams.get("HIBERNATE_PROPERTIES");
	if(hibernatePropertiesMap != null){
    stringBuffer.append(TEXT_2);
    	
		for(java.util.Iterator iter = hibernatePropertiesMap.keySet().iterator();iter.hasNext();){
		String param = (String) iter.next();
			if(param.startsWith("sdk.xml.comment")){
    stringBuffer.append(TEXT_3);
    stringBuffer.append((String)hibernatePropertiesMap.get(param));
    stringBuffer.append(TEXT_4);
    
			}else{
    stringBuffer.append(TEXT_5);
    stringBuffer.append(param);
    stringBuffer.append(TEXT_6);
    stringBuffer.append((String)hibernatePropertiesMap.get(param));
    stringBuffer.append(TEXT_7);
    		}
		}
	}
    stringBuffer.append(TEXT_8);
    for(UMLClass klass:transformerUtils.getAllHibernateClasses(model)){
    stringBuffer.append(TEXT_9);
    stringBuffer.append(transformerUtils.getFQCN(klass).replace('.','/'));
    stringBuffer.append(TEXT_10);
    }
    stringBuffer.append(TEXT_11);
    stringBuffer.append(TEXT_12);
    return stringBuffer.toString();
  }
}