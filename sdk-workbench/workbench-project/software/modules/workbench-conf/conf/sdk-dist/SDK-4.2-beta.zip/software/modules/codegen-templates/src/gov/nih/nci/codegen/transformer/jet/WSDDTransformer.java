package gov.nih.nci.codegen.transformer.jet;

import gov.nih.nci.codegen.transformer.UMLModelJETTransformer;
import gov.nih.nci.codegen.Artifact;
import gov.nih.nci.codegen.artifact.BaseArtifact;
import gov.nih.nci.codegen.util.TransformerUtils;
import gov.nih.nci.codegen.GenerationException;

import gov.nih.nci.ncicb.xmiinout.domain.UMLModel;
import gov.nih.nci.ncicb.xmiinout.domain.UMLClass;
import gov.nih.nci.ncicb.xmiinout.domain.UMLAssociation;
import gov.nih.nci.ncicb.xmiinout.domain.UMLAssociationEnd;
import gov.nih.nci.ncicb.xmiinout.domain.UMLAttribute;

import java.util.Collection;
import java.util.List;
import java.util.Map;

public class WSDDTransformer extends UMLModelJETTransformer{

	  protected final String NL = System.getProperties().getProperty("line.separator");
  protected final String TEXT_1 = "<deployment xmlns=\"http://xml.apache.org/axis/wsdd/\"" + NL + "\txmlns:java=\"http://xml.apache.org/axis/wsdd/providers/java\">" + NL + "<handler name=\"LocalResponder\" type=\"java:org.apache.axis.transport.local.LocalResponder\"/>" + NL + "<handler name=\"URLMapper\" type=\"java:org.apache.axis.handlers.http.URLMapper\"/>" + NL + "<handler name=\"Authenticate\" type=\"java:org.apache.axis.handlers.SimpleAuthenticationHandler\"/>" + NL + "<handler name=\"SecuritySOAPHandler\" type=\"java:gov.nih.nci.system.webservice.interceptor.ACEGISOAPHandler\"/>" + NL + "<service name=\"AdminService\" provider=\"java:MSG\">" + NL + "  <parameter name=\"allowedMethods\" value=\"AdminService\"/>" + NL + "  <parameter name=\"enableRemoteAdmin\" value=\"false\"/>" + NL + "  <parameter name=\"className\" value=\"org.apache.axis.utils.Admin\"/>" + NL + "  <namespace>http://xml.apache.org/axis/wsdd/</namespace>" + NL + "</service>" + NL + "<service name=\"Version\" provider=\"java:RPC\">" + NL + "  <parameter name=\"allowedMethods\" value=\"getVersion\"/>" + NL + "  <parameter name=\"className\" value=\"org.apache.axis.Version\"/>" + NL + "</service>" + NL + "<service name=\"";
  protected final String TEXT_2 = "\" style=\"java:RPC\" use=\"literal\">" + NL + "\t<requestFlow>" + NL + "\t\t<handler type=\"SecuritySOAPHandler\" />" + NL + "\t</requestFlow>" + NL + "\t<parameter name=\"className\" value=\"gov.nih.nci.system.webservice.WSQueryImpl\"/>" + NL + "\t<parameter name=\"allowedMethods\" value=\"*\"/>" + NL + "\t<parameter name=\"extraClasses\"" + NL + "\tvalue=\"";
  protected final String TEXT_3 = "\"/>";
  protected final String TEXT_4 = "\t" + NL + "\t<beanMapping xmlns:myNS=\"urn:";
  protected final String TEXT_5 = "\"  qname=\"myNS:";
  protected final String TEXT_6 = "\" languageSpecificType=\"java:";
  protected final String TEXT_7 = "\" />";
  protected final String TEXT_8 = "\t\t" + NL + "\t<beanMapping xmlns:myNS=\"urn:Character.lang.java\"  qname=\"myNS:Character\" languageSpecificType=\"java:java.lang.Character\" />\t\t" + NL + "</service>" + NL + "<transport name=\"http\">" + NL + "  <requestFlow>" + NL + "   <handler type=\"URLMapper\"/>" + NL + "   <handler type=\"java:org.apache.axis.handlers.http.HTTPAuthHandler\"/>" + NL + "  </requestFlow>" + NL + "</transport>" + NL + "<transport name=\"local\">" + NL + "  <responseFlow>" + NL + "   <handler type=\"LocalResponder\"/>" + NL + "  </responseFlow>" + NL + "</transport>" + NL + "</deployment>";

public Artifact executeTemplate(UMLModel model, Map<String, Object> configurationParams) throws GenerationException{
		BaseArtifact artifact = new BaseArtifact(transformerUtils);
		artifact.setContent(generate(model, configurationParams));
		return artifact;
	}
	
	public String generate(UMLModel model, Map configurationParams) throws GenerationException
  {
    StringBuffer stringBuffer = new StringBuffer();
      
	Collection<UMLClass> classColl = transformerUtils.getAllClasses(model);
	String pkgName;
 
    stringBuffer.append(TEXT_1);
    stringBuffer.append((String)configurationParams.get("WEBSERVICE_NAME"));
    stringBuffer.append(TEXT_2);
    stringBuffer.append(transformerUtils.getWSDDServiceValue(classColl));
    stringBuffer.append(TEXT_3);
     for(UMLClass klass:classColl){
	pkgName = transformerUtils.getFullPackageName(klass);

    stringBuffer.append(TEXT_4);
    stringBuffer.append(transformerUtils.reversePackageName(pkgName));
    stringBuffer.append(TEXT_5);
    stringBuffer.append(klass.getName());
    stringBuffer.append(TEXT_6);
    stringBuffer.append( pkgName + '.' + klass.getName());
    stringBuffer.append(TEXT_7);
     } 
    stringBuffer.append(TEXT_8);
    return stringBuffer.toString();
  }
}